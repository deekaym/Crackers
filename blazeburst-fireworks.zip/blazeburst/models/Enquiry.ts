import mongoose, { Schema, Document, Model } from 'mongoose'

export type EnquiryStatus = 'new' | 'contacted' | 'closed'

export interface EnquiryItem {
  productId: string
  productName: string
  quantity: number
  price: number
}

export interface IEnquiry extends Document {
  name: string
  phone: string
  city: string
  message?: string
  items: EnquiryItem[]
  estimatedTotal: number
  status: EnquiryStatus
  createdAt: Date
  updatedAt: Date
}

const EnquiryItemSchema = new Schema<EnquiryItem>(
  {
    productId: { type: String, required: true },
    productName: { type: String, required: true },
    quantity: { type: Number, required: true, min: 1 },
    price: { type: Number, required: true, min: 0 },
  },
  { _id: false }
)

const EnquirySchema = new Schema<IEnquiry>(
  {
    name: { type: String, required: true, trim: true },
    phone: { type: String, required: true, trim: true },
    city: { type: String, required: true, trim: true },
    message: { type: String, trim: true },
    items: { type: [EnquiryItemSchema], required: true, validate: [(v: EnquiryItem[]) => v.length > 0, 'At least one item required'] },
    estimatedTotal: { type: Number, required: true, min: 0 },
    status: { type: String, enum: ['new', 'contacted', 'closed'], default: 'new' },
  },
  { timestamps: true }
)

EnquirySchema.index({ status: 1 })
EnquirySchema.index({ createdAt: -1 })

const Enquiry: Model<IEnquiry> =
  mongoose.models.Enquiry || mongoose.model<IEnquiry>('Enquiry', EnquirySchema)

export default Enquiry
