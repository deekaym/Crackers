import mongoose, { Schema, Document, Model } from 'mongoose'

export type StockStatus = 'in_stock' | 'out_of_stock' | 'pre_order'

export interface IProduct extends Document {
  name: string
  slug: string
  category: mongoose.Types.ObjectId
  description: string
  shortDescription?: string
  price: number
  originalPrice?: number
  image: string
  images?: string[]
  stockStatus: StockStatus
  featured: boolean
  tags?: string[]
  specifications?: Record<string, string>
  createdAt: Date
  updatedAt: Date
}

const ProductSchema = new Schema<IProduct>(
  {
    name: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
    description: { type: String, required: true },
    shortDescription: { type: String, trim: true },
    price: { type: Number, required: true, min: 0 },
    originalPrice: { type: Number, min: 0 },
    image: { type: String, required: true },
    images: [{ type: String }],
    stockStatus: {
      type: String,
      enum: ['in_stock', 'out_of_stock', 'pre_order'],
      default: 'in_stock',
    },
    featured: { type: Boolean, default: false },
    tags: [{ type: String, trim: true }],
    specifications: { type: Map, of: String },
  },
  { timestamps: true }
)

ProductSchema.index({ slug: 1 })
ProductSchema.index({ category: 1 })
ProductSchema.index({ featured: 1 })
ProductSchema.index({ name: 'text', description: 'text', tags: 'text' })

const Product: Model<IProduct> =
  mongoose.models.Product || mongoose.model<IProduct>('Product', ProductSchema)

export default Product
