'use client'
import { useState } from 'react'
import { useCart } from './CartContext'

interface Props {
  product: { _id: string; name: string; price: number; image: string; slug: string; stockStatus: string }
}

export default function AddToCartButton({ product }: Props) {
  const { addItem, isInCart, toggleCart } = useCart()
  const [qty, setQty] = useState(1)
  const inCart = isInCart(product._id)
  const isOutOfStock = product.stockStatus === 'out_of_stock'

  function handleAdd() {
    addItem({ id: product._id, name: product.name, price: product.price, image: product.image, quantity: qty, slug: product.slug })
  }

  if (isOutOfStock) {
    return <button disabled className="w-full py-4 rounded-xl bg-white/5 text-gray-600 font-semibold cursor-not-allowed">Out of Stock</button>
  }

  return (
    <div className="flex gap-3">
      <div className="flex items-center border border-white/10 rounded-xl overflow-hidden">
        <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="w-11 h-12 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-colors text-xl">−</button>
        <span className="w-10 text-center text-white font-bold text-sm">{qty}</span>
        <button onClick={() => setQty((q) => q + 1)} className="w-11 h-12 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-colors text-xl">+</button>
      </div>
      {inCart ? (
        <button onClick={toggleCart} className="flex-1 btn-ghost py-4 border-green-500/40 text-green-400 hover:text-green-300">
          ✅ In Cart — View Cart
        </button>
      ) : (
        <button onClick={handleAdd} className="flex-1 btn-primary py-4">
          + Add to Enquiry Cart
        </button>
      )}
    </div>
  )
}
