'use client'
import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { useCart } from './CartContext'
import { formatPrice, getDiscountPercent } from '@/utils/helpers'

interface Product {
  _id: string
  name: string
  slug: string
  price: number
  originalPrice?: number
  image: string
  shortDescription?: string
  description: string
  stockStatus: string
  category: { name: string; slug: string }
  tags?: string[]
}

export default function ProductCard({ product }: { product: Product }) {
  const { addItem, isInCart } = useCart()
  const [added, setAdded] = useState(false)
  const inCart = isInCart(product._id)

  function handleAdd() {
    addItem({
      id: product._id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
      slug: product.slug,
    })
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  const isOutOfStock = product.stockStatus === 'out_of_stock'
  const discount = product.originalPrice ? getDiscountPercent(product.originalPrice, product.price) : 0

  return (
    <div className="group bg-[#1C1C26] border border-white/8 rounded-2xl overflow-hidden hover:border-orange-500/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-orange-500/10 flex flex-col">
      {/* Image */}
      <Link href={`/products/${product.slug}`} className="relative aspect-[4/3] block overflow-hidden bg-[#0A0A0F]">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-500"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          loading="lazy"
        />
        {discount > 0 && (
          <span className="absolute top-3 left-3 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-lg">
            -{discount}%
          </span>
        )}
        {isOutOfStock && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="bg-red-500 text-white text-sm font-bold px-4 py-2 rounded-lg">Out of Stock</span>
          </div>
        )}
        {product.stockStatus === 'pre_order' && (
          <span className="absolute top-3 right-3 bg-purple-500 text-white text-xs font-bold px-2 py-1 rounded-lg">Pre-Order</span>
        )}
      </Link>

      {/* Body */}
      <div className="p-4 flex-1 flex flex-col">
        <div className="text-xs text-orange-400 font-semibold uppercase tracking-wider mb-1">
          {product.category?.name}
        </div>
        <Link href={`/products/${product.slug}`}>
          <h3 className="text-sm font-bold text-white leading-snug mb-2 hover:text-orange-300 transition-colors line-clamp-2">
            {product.name}
          </h3>
        </Link>
        <p className="text-xs text-gray-500 leading-relaxed mb-3 line-clamp-2 flex-1">
          {product.shortDescription || product.description}
        </p>

        {product.tags && product.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {product.tags.slice(0, 3).map((tag) => (
              <span key={tag} className="text-xs bg-white/5 border border-white/8 text-gray-400 px-2 py-0.5 rounded-md">
                {tag}
              </span>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between mt-auto pt-3 border-t border-white/8">
          <div>
            <div className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-400">
              {formatPrice(product.price)}
            </div>
            {product.originalPrice && (
              <div className="text-xs text-gray-500 line-through">{formatPrice(product.originalPrice)}</div>
            )}
          </div>

          <button
            onClick={handleAdd}
            disabled={isOutOfStock}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-95 ${
              inCart || added
                ? 'bg-green-500/20 border border-green-500/40 text-green-400'
                : isOutOfStock
                ? 'bg-white/5 text-gray-600 cursor-not-allowed'
                : 'bg-gradient-to-r from-orange-600 to-yellow-500 text-white hover:shadow-lg hover:shadow-orange-500/30'
            }`}
          >
            {inCart || added ? (
              <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>Added</>
            ) : isOutOfStock ? (
              'Unavailable'
            ) : (
              <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>Enquire</>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
