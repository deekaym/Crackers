'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'

const NAV = [
  { href: '/admin', icon: '📊', label: 'Dashboard' },
  { href: '/admin/enquiries', icon: '📋', label: 'Enquiries' },
  { href: '/admin/products', icon: '🎆', label: 'Products' },
  { href: '/admin/categories', icon: '📁', label: 'Categories' },
]

export default function AdminSidebar() {
  const pathname = usePathname()
  const router = useRouter()

  async function handleLogout() {
    await fetch('/api/admin/auth', { method: 'DELETE' }).catch(() => {})
    localStorage.removeItem('bb_admin_token')
    document.cookie = 'bb_admin_token=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/'
    router.push('/admin/login')
  }

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-[#0D0D14] border-r border-white/8 flex flex-col z-10">
      <div className="p-6 border-b border-white/8">
        <div className="flex items-center gap-2">
          <span className="text-xl">🎆</span>
          <span className="font-bold text-white">Admin Panel</span>
        </div>
        <p className="text-xs text-gray-600 mt-1">Blaze & Burst</p>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {NAV.map(({ href, icon, label }) => {
          const active = pathname === href || (href !== '/admin' && pathname.startsWith(href))
          return (
            <Link key={href} href={href}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${active ? 'bg-orange-600/20 text-orange-300 border border-orange-500/25' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
              <span className="text-base">{icon}</span>
              {label}
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t border-white/8 space-y-2">
        <Link href="/" target="_blank"
          className="flex items-center gap-2 text-xs text-gray-500 hover:text-gray-300 transition-colors px-2 py-1.5">
          🌐 View Website →
        </Link>
        <button onClick={handleLogout}
          className="w-full flex items-center gap-2 text-xs text-gray-500 hover:text-red-400 transition-colors px-2 py-1.5">
          🚪 Sign Out
        </button>
      </div>
    </aside>
  )
}
