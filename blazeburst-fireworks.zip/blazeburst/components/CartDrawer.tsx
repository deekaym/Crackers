'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useCart } from './CartContext'
import { formatPrice } from '@/utils/helpers'

export default function CartDrawer() {
  const { items, isOpen, setOpen, removeItem, updateQty, clearCart, totalPrice, totalItems } = useCart()
  const [step, setStep] = useState<'cart' | 'form' | 'success'>('cart')
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ name: '', phone: '', city: '', message: '' })
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (isOpen) document.body.style.overflow = 'hidden'
    else document.body.style.overflow = ''
    return () => { document.body.style.overflow = '' }
  }, [isOpen])

  useEffect(() => {
    if (!isOpen) { setStep('cart'); setErrors({}) }
  }, [isOpen])

  function validate() {
    const e: Record<string, string> = {}
    if (!form.name.trim()) e.name = 'Name is required'
    if (!form.phone.trim()) e.phone = 'Phone is required'
    else if (!/^[6-9]\d{9}$/.test(form.phone.replace(/\s/g, ''))) e.phone = 'Enter valid 10-digit mobile number'
    if (!form.city.trim()) e.city = 'City is required'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!validate()) return
    setLoading(true)
    try {
      const payload = {
        ...form,
        items: items.map((i) => ({ productId: i.id, productName: i.name, quantity: i.quantity, price: i.price })),
      }
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)

      setStep('success')
      clearCart()
      setTimeout(() => {
        if (data.whatsappURL) window.open(data.whatsappURL, '_blank')
      }, 500)
    } catch (err) {
      alert('Failed to submit enquiry. Please try again.')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity"
        onClick={() => setOpen(false)}
      />

      {/* Drawer */}
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-[#13131A] border-l border-white/10 z-50 flex flex-col shadow-2xl animate-[slideIn_0.3s_ease]"
        style={{ animation: 'slideIn 0.3s ease' }}>
        <style>{`@keyframes slideIn{from{transform:translateX(100%)}to{transform:translateX(0)}}`}</style>

        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div>
            <h2 className="text-xl font-bold text-white">Enquiry Cart</h2>
            <p className="text-sm text-gray-400">{totalItems} item{totalItems !== 1 ? 's' : ''}</p>
          </div>
          <button onClick={() => setOpen(false)} className="text-gray-400 hover:text-white transition-colors p-2 rounded-lg hover:bg-white/10">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {step === 'cart' && (
            <>
              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full p-8 text-center">
                  <div className="text-6xl mb-4">🛒</div>
                  <h3 className="text-lg font-semibold text-white mb-2">Cart is empty</h3>
                  <p className="text-gray-400 text-sm mb-6">Browse our catalogue and add products to enquire</p>
                  <button onClick={() => setOpen(false)} className="btn-primary">Browse Products</button>
                </div>
              ) : (
                <div className="p-4 space-y-3">
                  {items.map((item) => (
                    <div key={item.id} className="bg-[#1C1C26] border border-white/8 rounded-xl p-4 flex gap-3">
                      <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                        <Image src={item.image} alt={item.name} fill className="object-cover" sizes="64px" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{item.name}</p>
                        <p className="text-sm text-orange-400 font-bold mt-0.5">{formatPrice(item.price)}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <button onClick={() => updateQty(item.id, item.quantity - 1)} disabled={item.quantity <= 1}
                            className="w-7 h-7 rounded-lg bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-colors disabled:opacity-40 text-lg">−</button>
                          <span className="text-sm font-bold text-white w-6 text-center">{item.quantity}</span>
                          <button onClick={() => updateQty(item.id, item.quantity + 1)}
                            className="w-7 h-7 rounded-lg bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-colors text-lg">+</button>
                          <span className="text-xs text-gray-500 ml-1">= {formatPrice(item.price * item.quantity)}</span>
                        </div>
                      </div>
                      <button onClick={() => removeItem(item.id)} className="text-gray-500 hover:text-red-400 transition-colors self-start mt-1">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {step === 'form' && (
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <h3 className="text-lg font-bold text-white mb-1">Your Details</h3>
                <p className="text-sm text-gray-400">We&apos;ll contact you to confirm your enquiry</p>
              </div>
              {([
                { key: 'name', label: 'Full Name', type: 'text', placeholder: 'Ramesh Kumar' },
                { key: 'phone', label: 'Mobile Number', type: 'tel', placeholder: '9876543210' },
                { key: 'city', label: 'City', type: 'text', placeholder: 'Chennai' },
              ] as const).map(({ key, label, type, placeholder }) => (
                <div key={key}>
                  <label className="block text-sm font-medium text-gray-300 mb-1.5">{label} <span className="text-red-400">*</span></label>
                  <input type={type} placeholder={placeholder} value={form[key]}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    className={`w-full bg-white/5 border ${errors[key] ? 'border-red-500' : 'border-white/10'} rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-orange-500 transition-colors text-sm`}
                  />
                  {errors[key] && <p className="text-xs text-red-400 mt-1">{errors[key]}</p>}
                </div>
              ))}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1.5">Message (optional)</label>
                <textarea placeholder="Delivery address, event date, special requirements…"
                  value={form.message} onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-orange-500 transition-colors text-sm resize-none"
                />
              </div>
              {/* Summary */}
              <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-4">
                <p className="text-sm text-gray-300 mb-1">{totalItems} products in enquiry</p>
                <p className="text-lg font-bold text-orange-400">Est. Total: {formatPrice(totalPrice)}</p>
              </div>
            </form>
          )}

          {step === 'success' && (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <div className="text-6xl mb-4 animate-bounce">🎉</div>
              <h3 className="text-xl font-bold text-white mb-2">Enquiry Submitted!</h3>
              <p className="text-gray-400 text-sm mb-2">We&apos;ve received your enquiry.</p>
              <p className="text-gray-400 text-sm mb-6">Redirecting you to WhatsApp for instant confirmation…</p>
              <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 text-center">
                <p className="text-green-400 text-sm font-semibold">✅ Your message is ready on WhatsApp</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {step === 'cart' && items.length > 0 && (
          <div className="border-t border-white/10 p-5 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Estimated Total</span>
              <span className="text-xl font-bold text-orange-400">{formatPrice(totalPrice)}</span>
            </div>
            <p className="text-xs text-gray-500">Final prices confirmed at delivery. Bulk discounts may apply.</p>
            <button onClick={() => setStep('form')} className="w-full btn-primary py-4 text-base font-semibold">
              Proceed to Enquiry →
            </button>
          </div>
        )}

        {step === 'form' && (
          <div className="border-t border-white/10 p-5 flex gap-3">
            <button type="button" onClick={() => setStep('cart')} className="flex-1 btn-ghost py-4">← Back</button>
            <button onClick={handleSubmit} disabled={loading}
              className="flex-2 flex-grow-[2] btn-whatsapp py-4 font-semibold disabled:opacity-60 flex items-center justify-center gap-2">
              {loading ? 'Submitting…' : (<><span>Send via WhatsApp</span><span>💬</span></>)}
            </button>
          </div>
        )}
      </div>
    </>
  )
}
