import { type ClassValue, clsx } from 'clsx'

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs)
}

export function formatPrice(price: number): string {
  return `₹${price.toLocaleString('en-IN')}`
}

export function truncate(str: string, length: number): string {
  return str.length > length ? str.slice(0, length) + '...' : str
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}

export function getDiscountPercent(original: number, sale: number): number {
  return Math.round(((original - sale) / original) * 100)
}

export function generateCSV(enquiries: Record<string, unknown>[]): string {
  if (!enquiries.length) return ''

  const headers = ['ID', 'Name', 'Phone', 'City', 'Items', 'Total', 'Status', 'Date']
  const rows = enquiries.map((e: Record<string, unknown>) => {
    const items = (e.items as Array<{ productName: string; quantity: number; price: number }>)
      ?.map((i) => `${i.productName}(${i.quantity})`)
      .join('; ')
    const date = e.createdAt ? new Date(e.createdAt as string).toLocaleDateString('en-IN') : ''
    return [
      e._id as string,
      `"${e.name}"`,
      e.phone as string,
      `"${e.city}"`,
      `"${items}"`,
      `₹${(e.estimatedTotal as number)?.toLocaleString('en-IN')}`,
      e.status as string,
      date,
    ].join(',')
  })

  return [headers.join(','), ...rows].join('\n')
}

export function buildMetaTags({
  title,
  description,
  image,
  url,
  type = 'website',
}: {
  title: string
  description: string
  image?: string
  url?: string
  type?: string
}) {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://blazeburst.com'
  const fullUrl = url ? `${siteUrl}${url}` : siteUrl
  const ogImage = image || `${siteUrl}/og-image.jpg`

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      url: fullUrl,
      type,
      images: [{ url: ogImage, width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [ogImage],
    },
    alternates: { canonical: fullUrl },
  }
}
