import nodemailer from 'nodemailer'
import { EnquiryItem } from '@/models/Enquiry'

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: parseInt(process.env.EMAIL_PORT || '587'),
  secure: process.env.EMAIL_PORT === '465',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
})

export interface EnquiryEmailData {
  name: string
  phone: string
  city: string
  message?: string
  items: EnquiryItem[]
  estimatedTotal: number
  enquiryId: string
}

export async function sendEnquiryNotification(data: EnquiryEmailData) {
  const itemsTable = data.items
    .map(
      (item, i) =>
        `<tr style="background:${i % 2 === 0 ? '#f9f9f9' : '#ffffff'}">
          <td style="padding:10px 12px;border:1px solid #e5e7eb">${item.productName}</td>
          <td style="padding:10px 12px;border:1px solid #e5e7eb;text-align:center">${item.quantity}</td>
          <td style="padding:10px 12px;border:1px solid #e5e7eb;text-align:right">₹${item.price.toLocaleString('en-IN')}</td>
          <td style="padding:10px 12px;border:1px solid #e5e7eb;text-align:right">₹${(item.price * item.quantity).toLocaleString('en-IN')}</td>
        </tr>`
    )
    .join('')

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>New Enquiry</title></head>
<body style="font-family:Arial,sans-serif;background:#f3f4f6;padding:20px">
  <div style="max-width:600px;margin:0 auto;background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.1)">
    <div style="background:linear-gradient(135deg,#FF4500,#FFB800);padding:28px 32px">
      <h1 style="margin:0;color:white;font-size:22px">🎆 New Firework Enquiry</h1>
      <p style="margin:8px 0 0;color:rgba(255,255,255,0.85);font-size:14px">Enquiry ID: #${data.enquiryId}</p>
    </div>
    <div style="padding:32px">
      <h2 style="font-size:16px;color:#111827;margin:0 0 16px">Customer Details</h2>
      <table style="width:100%;border-collapse:collapse;margin-bottom:24px">
        <tr><td style="padding:8px 0;color:#6b7280;width:120px">Name</td><td style="padding:8px 0;font-weight:600;color:#111827">${data.name}</td></tr>
        <tr><td style="padding:8px 0;color:#6b7280">Phone</td><td style="padding:8px 0;font-weight:600;color:#111827">${data.phone}</td></tr>
        <tr><td style="padding:8px 0;color:#6b7280">City</td><td style="padding:8px 0;font-weight:600;color:#111827">${data.city}</td></tr>
        ${data.message ? `<tr><td style="padding:8px 0;color:#6b7280;vertical-align:top">Message</td><td style="padding:8px 0;color:#111827">${data.message}</td></tr>` : ''}
      </table>
      <h2 style="font-size:16px;color:#111827;margin:0 0 12px">Products Requested</h2>
      <table style="width:100%;border-collapse:collapse;margin-bottom:24px">
        <thead>
          <tr style="background:#FF4500">
            <th style="padding:10px 12px;text-align:left;color:white;font-size:13px">Product</th>
            <th style="padding:10px 12px;text-align:center;color:white;font-size:13px">Qty</th>
            <th style="padding:10px 12px;text-align:right;color:white;font-size:13px">Unit Price</th>
            <th style="padding:10px 12px;text-align:right;color:white;font-size:13px">Subtotal</th>
          </tr>
        </thead>
        <tbody>${itemsTable}</tbody>
      </table>
      <div style="background:#FFF3E0;border:1px solid #FFB800;border-radius:8px;padding:16px;text-align:right">
        <span style="font-size:18px;font-weight:700;color:#FF4500">Estimated Total: ₹${data.estimatedTotal.toLocaleString('en-IN')}</span>
      </div>
      <div style="margin-top:24px;padding:16px;background:#f0fdf4;border-radius:8px;border-left:4px solid #22c55e">
        <p style="margin:0;font-size:13px;color:#166534">
          💬 Reply via WhatsApp: <a href="https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}" style="color:#16a34a">+91 ${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}</a>
        </p>
      </div>
    </div>
    <div style="background:#f9fafb;padding:16px 32px;text-align:center">
      <p style="margin:0;font-size:12px;color:#9ca3af">Blaze & Burst Fireworks — Admin Notification</p>
    </div>
  </div>
</body>
</html>`

  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to: process.env.ADMIN_EMAIL_RECIPIENT,
    subject: `🎆 New Firework Enquiry from ${data.name} (${data.city}) — ₹${data.estimatedTotal.toLocaleString('en-IN')}`,
    html,
  })
}

export async function sendEnquiryConfirmation(data: EnquiryEmailData & { email?: string }) {
  if (!data.email) return

  const html = `
<!DOCTYPE html>
<html>
<body style="font-family:Arial,sans-serif;background:#f3f4f6;padding:20px">
  <div style="max-width:600px;margin:0 auto;background:white;border-radius:12px;overflow:hidden">
    <div style="background:linear-gradient(135deg,#FF4500,#FFB800);padding:28px 32px">
      <h1 style="margin:0;color:white">Thank you, ${data.name}! 🎆</h1>
    </div>
    <div style="padding:32px">
      <p>We've received your enquiry and will contact you shortly via WhatsApp or phone.</p>
      <p style="color:#6b7280;font-size:14px">Your enquiry reference: <strong>#${data.enquiryId}</strong></p>
      <p>For faster response, you can also reach us directly:</p>
      <a href="https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}" 
         style="display:inline-block;background:#25D366;color:white;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600">
        💬 Chat on WhatsApp
      </a>
    </div>
  </div>
</body>
</html>`

  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to: data.email,
    subject: 'Your Enquiry Received — Blaze & Burst Fireworks',
    html,
  })
}
