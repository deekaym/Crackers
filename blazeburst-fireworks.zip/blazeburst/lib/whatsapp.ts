import { EnquiryItem } from '@/models/Enquiry'

export interface WhatsAppEnquiryData {
  name: string
  phone: string
  city: string
  message?: string
  items: EnquiryItem[]
  estimatedTotal: number
}

export function generateWhatsAppMessage(data: WhatsAppEnquiryData): string {
  const itemLines = data.items
    .map(
      (item, i) =>
        `${i + 1}. *${item.productName}* – Qty ${item.quantity} – ₹${(item.price * item.quantity).toLocaleString('en-IN')}`
    )
    .join('\n')

  const message = `Hi Blaze & Burst! 🎆 I would like to enquire about the following products:

${itemLines}

💰 *Estimated Total: ₹${data.estimatedTotal.toLocaleString('en-IN')}*

📋 *Customer Details:*
👤 Name: ${data.name}
📞 Phone: ${data.phone}
📍 City: ${data.city}${data.message ? `\n💬 Message: ${data.message}` : ''}

Please confirm availability and delivery charges. Thank you!`

  return message
}

export function buildWhatsAppURL(message: string, phoneNumber?: string): string {
  const phone = phoneNumber || process.env.NEXT_PUBLIC_WHATSAPP_NUMBER
  const encoded = encodeURIComponent(message)
  return `https://wa.me/${phone}?text=${encoded}`
}

export function buildEnquiryWhatsAppURL(data: WhatsAppEnquiryData): string {
  const message = generateWhatsAppMessage(data)
  return buildWhatsAppURL(message)
}
