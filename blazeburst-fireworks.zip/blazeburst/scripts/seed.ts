import 'dotenv/config'
import mongoose from 'mongoose'

const MONGODB_URI = process.env.MONGODB_URI!

const CATEGORIES = [
  { name: 'Aerial Shots', slug: 'aerial-shots', image: 'https://images.unsplash.com/photo-1514222788835-3a1a1d5b32f8?w=400', description: 'Multi-shot aerial fireworks with stunning effects', sortOrder: 1 },
  { name: 'Sparklers', slug: 'sparklers', image: 'https://images.unsplash.com/photo-1467810563316-b5476525c0f9?w=400', description: 'Hand-held sparklers for all ages', sortOrder: 2 },
  { name: 'Rockets', slug: 'rockets', image: 'https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=400', description: 'Single-shot rockets reaching great heights', sortOrder: 3 },
  { name: 'Ground Chakkar', slug: 'ground-chakkar', image: 'https://images.unsplash.com/photo-1526716531088-6de44ece7c98?w=400', description: 'Spinning ground wheels with vibrant sparks', sortOrder: 4 },
  { name: 'Flower Pots', slug: 'flower-pots', image: 'https://images.unsplash.com/photo-1533294455009-a77b7557d2d1?w=400', description: 'Fountain fireworks with colourful sprays', sortOrder: 5 },
  { name: 'Sound Crackers', slug: 'sound-crackers', image: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=400', description: 'Traditional crackers with celebratory sounds', sortOrder: 6 },
  { name: 'Fancy Items', slug: 'fancy-items', image: 'https://images.unsplash.com/photo-1577223625816-7546f13df25d?w=400', description: 'Novelty and special effect fireworks', sortOrder: 7 },
  { name: 'Gift Boxes', slug: 'gift-boxes', image: 'https://images.unsplash.com/photo-1512909006721-3d6018887383?w=400', description: 'Curated assortment boxes for gifting', sortOrder: 8 },
]

async function seed() {
  await mongoose.connect(MONGODB_URI)
  console.log('Connected to MongoDB')

  // Import models
  const { default: Category } = await import('./models/Category')
  const { default: Product } = await import('./models/Product')
  const { default: Admin } = await import('./models/Admin')

  // Clear existing
  await Promise.all([Category.deleteMany({}), Product.deleteMany({})])

  // Seed categories
  const createdCats = await Category.insertMany(CATEGORIES)
  console.log(`✅ Seeded ${createdCats.length} categories`)

  const catMap = Object.fromEntries(createdCats.map((c) => [c.slug, c._id]))

  // Seed products
  const PRODUCTS = [
    { name: 'Golden Galaxy 10-Shot Aerial', slug: 'golden-galaxy-10-shot-aerial', category: catMap['aerial-shots'], price: 899, originalPrice: 1099, image: 'https://images.unsplash.com/photo-1514222788835-3a1a1d5b32f8?w=600', description: '10-shot aerial shell with stunning golden palm effect. Brilliant 80ft burst radius with crackling silver stars finale.', shortDescription: '10-shot golden palm aerial with 80ft burst', featured: true, stockStatus: 'in_stock', tags: ['80ft Burst', 'Golden Effect', '10 Shots', 'Premium'] },
    { name: 'Princess Sparkler Pack (20pcs)', slug: 'princess-sparkler-pack', category: catMap['sparklers'], price: 149, image: 'https://images.unsplash.com/photo-1467810563316-b5476525c0f9?w=600', description: 'Long-lasting 30cm sparklers. Burns brightly for 60 seconds. Safe for supervised use. Perfect for celebrations and photos.', shortDescription: '30cm sparklers, 60-second burn, pack of 20', featured: true, stockStatus: 'in_stock', tags: ['Pack of 20', '60 Seconds', 'Photography'] },
    { name: 'Sky Rocket Elite', slug: 'sky-rocket-elite', category: catMap['rockets'], price: 549, image: 'https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=600', description: 'Single-shot rocket reaching 200ft altitude with crackling golden stars and a loud report. Premium Sivakasi quality.', shortDescription: 'Single-shot, 200ft, golden stars', featured: true, stockStatus: 'in_stock', tags: ['200ft Height', 'Golden Stars', 'Premium'] },
    { name: 'Whirlwind Ground Chakkar (6pcs)', slug: 'whirlwind-ground-chakkar', category: catMap['ground-chakkar'], price: 299, image: 'https://images.unsplash.com/photo-1526716531088-6de44ece7c98?w=600', description: 'Fast spinning ground wheel with stunning multi-color sparks. Each wheel burns for 3 minutes of continuous colour.', shortDescription: 'Box of 6, multi-colour, 3 min burn', stockStatus: 'in_stock', tags: ['Box of 6', 'Multi-color', '3 Minutes'] },
    { name: 'Colour Fountain Pot', slug: 'colour-fountain-pot', category: catMap['flower-pots'], price: 249, image: 'https://images.unsplash.com/photo-1533294455009-a77b7557d2d1?w=600', description: 'Vibrant 7-colour fountain spray that burns beautifully for 2 minutes. Safe and colourful.', shortDescription: '7 colours, 2 min burn', stockStatus: 'in_stock', tags: ['7 Colours', '2 Min Burn'] },
    { name: 'Thunder King Sound Cracker (10pcs)', slug: 'thunder-king-sound-cracker', category: catMap['sound-crackers'], price: 199, image: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=600', description: 'Classic sound cracker with extra loud burst. Traditional festive experience. Box of 10 pieces.', shortDescription: 'Extra loud, box of 10', featured: true, stockStatus: 'in_stock', tags: ['Box of 10', 'Extra Loud', 'Traditional'] },
    { name: 'Diwali Mega Gift Box', slug: 'diwali-mega-gift-box', category: catMap['gift-boxes'], price: 2499, originalPrice: 3199, image: 'https://images.unsplash.com/photo-1512909006721-3d6018887383?w=600', description: 'Curated assortment of 50 premium items. Includes aerial shots, sparklers, rockets, chakkar and more. Perfect family Diwali set.', shortDescription: '50 premium items, perfect family set', featured: true, stockStatus: 'in_stock', tags: ['50 Items', 'Best Value', 'Family Pack'] },
    { name: 'Multi-Shot Rapid Fire 25', slug: 'multi-shot-rapid-fire-25', category: catMap['aerial-shots'], price: 1299, image: 'https://images.unsplash.com/photo-1514222788835-3a1a1d5b32f8?w=600', description: '25-shot rapid fire aerial with alternating red, gold and blue effects. A crowd favourite at every celebration.', shortDescription: '25 shots, 3 colours, rapid fire', featured: true, stockStatus: 'in_stock', tags: ['25 Shots', '3 Colours', 'Rapid Fire'] },
  ]

  const createdProducts = await Product.insertMany(PRODUCTS)
  console.log(`✅ Seeded ${createdProducts.length} products`)

  // Seed admin
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@blazeburst.com'
  const existing = await Admin.findOne({ email: adminEmail })
  if (!existing) {
    await Admin.create({
      email: adminEmail,
      password: process.env.ADMIN_PASSWORD || 'Admin@123456',
      name: 'Admin',
    })
    console.log(`✅ Created admin: ${adminEmail}`)
  } else {
    console.log('ℹ️ Admin already exists')
  }

  console.log('\n🎆 Database seeded successfully!')
  process.exit(0)
}

seed().catch((err) => { console.error(err); process.exit(1) })
