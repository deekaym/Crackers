import { NextRequest, NextResponse } from 'next/server'
import connectDB from '@/lib/db'
import Enquiry from '@/models/Enquiry'
import { verifyRequest } from '@/lib/auth'
import { generateCSV } from '@/utils/helpers'

export async function GET(req: NextRequest) {
  if (!verifyRequest(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const status = searchParams.get('status')
    const export_csv = searchParams.get('export') === 'csv'
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')

    const query = status && status !== 'all' ? { status } : {}

    if (export_csv) {
      const enquiries = await Enquiry.find(query).sort({ createdAt: -1 }).lean()
      const csv = generateCSV(enquiries as unknown as Record<string, unknown>[])
      return new NextResponse(csv, {
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': `attachment; filename="enquiries-${Date.now()}.csv"`,
        },
      })
    }

    const skip = (page - 1) * limit
    const [enquiries, total] = await Promise.all([
      Enquiry.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
      Enquiry.countDocuments(query),
    ])

    return NextResponse.json({ enquiries, total, page, pages: Math.ceil(total / limit) })
  } catch {
    return NextResponse.json({ error: 'Failed to fetch' }, { status: 500 })
  }
}
