import { NextRequest, NextResponse } from 'next/server'
import connectDB from '@/lib/db'
import Enquiry from '@/models/Enquiry'
import { verifyRequest } from '@/lib/auth'

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  if (!verifyRequest(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  try {
    await connectDB()
    const { status } = await req.json()
    if (!['new', 'contacted', 'closed'].includes(status))
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 })
    const enquiry = await Enquiry.findByIdAndUpdate(params.id, { status }, { new: true })
    if (!enquiry) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    return NextResponse.json({ enquiry })
  } catch {
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  if (!verifyRequest(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  try {
    await connectDB()
    await Enquiry.findByIdAndDelete(params.id)
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
