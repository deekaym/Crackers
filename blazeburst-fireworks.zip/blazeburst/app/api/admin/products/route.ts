import { NextRequest, NextResponse } from 'next/server'
import connectDB from '@/lib/db'
import Product from '@/models/Product'
import { verifyRequest } from '@/lib/auth'
import { slugify } from '@/utils/helpers'

function requireAuth(req: NextRequest) {
  const payload = verifyRequest(req)
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  return null
}

export async function GET(req: NextRequest) {
  const authError = requireAuth(req)
  if (authError) return authError
  try {
    await connectDB()
    const products = await Product.find({})
      .populate('category', 'name slug')
      .sort({ createdAt: -1 })
      .lean()
    return NextResponse.json({ products })
  } catch {
    return NextResponse.json({ error: 'Failed to fetch' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const authError = requireAuth(req)
  if (authError) return authError
  try {
    await connectDB()
    const body = await req.json()
    const { name, category, description, shortDescription, price, originalPrice, image, images, stockStatus, featured, tags, specifications } = body

    if (!name || !category || !description || !price || !image)
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })

    const baseSlug = slugify(name)
    let slug = baseSlug
    let counter = 1
    while (await Product.findOne({ slug })) {
      slug = `${baseSlug}-${counter++}`
    }

    const product = await Product.create({
      name, slug, category, description, shortDescription, price, originalPrice,
      image, images, stockStatus: stockStatus || 'in_stock',
      featured: !!featured, tags, specifications,
    })

    return NextResponse.json({ product }, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Failed to create product' }, { status: 500 })
  }
}
