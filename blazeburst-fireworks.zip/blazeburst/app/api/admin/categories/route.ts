import { NextRequest, NextResponse } from 'next/server'
import connectDB from '@/lib/db'
import Category from '@/models/Category'
import { verifyRequest } from '@/lib/auth'
import { slugify } from '@/utils/helpers'

export async function GET(req: NextRequest) {
  if (!verifyRequest(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  try {
    await connectDB()
    const categories = await Category.find({}).sort({ sortOrder: 1 }).lean()
    return NextResponse.json({ categories })
  } catch {
    return NextResponse.json({ error: 'Failed to fetch' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  if (!verifyRequest(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  try {
    await connectDB()
    const { name, image, description, sortOrder } = await req.json()
    if (!name || !image) return NextResponse.json({ error: 'Name and image required' }, { status: 400 })

    const baseSlug = slugify(name)
    let slug = baseSlug, counter = 1
    while (await Category.findOne({ slug })) slug = `${baseSlug}-${counter++}`

    const category = await Category.create({ name, slug, image, description, sortOrder: sortOrder || 0 })
    return NextResponse.json({ category }, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}
