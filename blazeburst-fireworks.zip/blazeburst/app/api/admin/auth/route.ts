import { NextRequest, NextResponse } from 'next/server'
import connectDB from '@/lib/db'
import Admin from '@/models/Admin'
import { signToken, setAuthCookie } from '@/lib/auth'

export async function POST(req: NextRequest) {
  try {
    await connectDB()
    const { email, password } = await req.json()

    if (!email || !password)
      return NextResponse.json({ error: 'Email and password required' }, { status: 400 })

    const admin = await Admin.findOne({ email: email.toLowerCase() })
    if (!admin)
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })

    const isValid = await admin.comparePassword(password)
    if (!isValid)
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })

    const token = signToken({ adminId: admin._id.toString(), email: admin.email })
    setAuthCookie(token)

    return NextResponse.json({
      success: true,
      admin: { id: admin._id, email: admin.email, name: admin.name },
      token,
    })
  } catch (error) {
    console.error('POST /api/admin/auth error:', error)
    return NextResponse.json({ error: 'Login failed' }, { status: 500 })
  }
}
