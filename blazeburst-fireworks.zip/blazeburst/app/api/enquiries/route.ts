import { NextRequest, NextResponse } from 'next/server'
import connectDB from '@/lib/db'
import Enquiry from '@/models/Enquiry'
import { sendEnquiryNotification } from '@/lib/email'
import { buildEnquiryWhatsAppURL } from '@/lib/whatsapp'

export async function POST(req: NextRequest) {
  try {
    await connectDB()
    const body = await req.json()
    const { name, phone, city, message, items } = body

    // Validation
    if (!name?.trim()) return NextResponse.json({ error: 'Name is required' }, { status: 400 })
    if (!phone?.trim()) return NextResponse.json({ error: 'Phone is required' }, { status: 400 })
    if (!city?.trim()) return NextResponse.json({ error: 'City is required' }, { status: 400 })
    if (!Array.isArray(items) || items.length === 0)
      return NextResponse.json({ error: 'At least one item is required' }, { status: 400 })

    const estimatedTotal = items.reduce(
      (sum: number, item: { price: number; quantity: number }) =>
        sum + item.price * item.quantity,
      0
    )

    const enquiry = await Enquiry.create({
      name: name.trim(),
      phone: phone.trim(),
      city: city.trim(),
      message: message?.trim(),
      items,
      estimatedTotal,
      status: 'new',
    })

    // Send email notification (non-blocking)
    sendEnquiryNotification({
      name,
      phone,
      city,
      message,
      items,
      estimatedTotal,
      enquiryId: enquiry._id.toString(),
    }).catch((err) => console.error('Email notification failed:', err))

    const whatsappURL = buildEnquiryWhatsAppURL({ name, phone, city, message, items, estimatedTotal })

    return NextResponse.json(
      { success: true, enquiryId: enquiry._id.toString(), whatsappURL },
      { status: 201 }
    )
  } catch (error) {
    console.error('POST /api/enquiries error:', error)
    return NextResponse.json({ error: 'Failed to submit enquiry' }, { status: 500 })
  }
}
