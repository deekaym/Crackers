import type { Metadata } from 'next'
import './globals.css'
import { CartProvider } from '@/components/CartContext'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import CartDrawer from '@/components/CartDrawer'
import WhatsAppFloat from '@/components/WhatsAppFloat'

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://blazeburst.com'

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'Blaze & Burst — Premium Fireworks Catalogue | Sivakasi',
    template: '%s | Blaze & Burst Fireworks',
  },
  description:
    'Browse 500+ premium fireworks from Sivakasi. Aerial shots, sparklers, rockets, gift boxes & more. WhatsApp enquiry system. Fast delivery across India.',
  keywords: ['fireworks', 'firecrackers', 'sivakasi', 'Diwali crackers', 'aerial shots', 'sparklers', 'buy fireworks online', 'wholesale fireworks'],
  openGraph: {
    type: 'website',
    siteName: 'Blaze & Burst Fireworks',
    url: siteUrl,
    images: [{ url: `${siteUrl}/og-image.jpg`, width: 1200, height: 630 }],
  },
  twitter: { card: 'summary_large_image' },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
  verification: { google: 'your-google-verification-code' },
}

const structuredData = {
  '@context': 'https://schema.org',
  '@type': 'Store',
  name: 'Blaze & Burst Fireworks',
  description: 'Premium fireworks and firecrackers from Sivakasi, India',
  url: siteUrl,
  telephone: `+${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}`,
  address: {
    '@type': 'PostalAddress',
    addressLocality: 'Sivakasi',
    addressRegion: 'Tamil Nadu',
    postalCode: '626123',
    addressCountry: 'IN',
  },
  openingHoursSpecification: {
    '@type': 'OpeningHoursSpecification',
    dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    opens: '09:00',
    closes: '19:00',
  },
  priceRange: '₹₹',
  sameAs: [`https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}`],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
        />
      </head>
      <body className="bg-[#0A0A0F] text-[#F5F0E8] antialiased">
        <CartProvider>
          <Navbar />
          <main>{children}</main>
          <Footer />
          <CartDrawer />
          <WhatsAppFloat />
        </CartProvider>
      </body>
    </html>
  )
}
