'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { formatPrice } from '@/utils/helpers'

interface Product { _id: string; name: string; price: number; image: string; stockStatus: string; featured: boolean; category: { name: string } }
interface Category { _id: string; name: string }

const EMPTY_FORM = { name: '', category: '', description: '', shortDescription: '', price: '', originalPrice: '', image: '', stockStatus: 'in_stock', featured: false, tags: '', specifications: '' }

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [saving, setSaving] = useState(false)

  const token = typeof window !== 'undefined' ? localStorage.getItem('bb_admin_token') : ''
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }

  useEffect(() => { fetchAll() }, [])

  async function fetchAll() {
    setLoading(true)
    const [pr, cr] = await Promise.all([
      fetch('/api/admin/products', { headers }).then((r) => r.json()),
      fetch('/api/admin/categories', { headers }).then((r) => r.json()),
    ])
    setProducts(pr.products || [])
    setCategories(cr.categories || [])
    setLoading(false)
  }

  function startCreate() { setForm(EMPTY_FORM); setEditId(null); setShowForm(true) }
  function startEdit(p: Product) {
    setForm({ ...EMPTY_FORM, name: p.name, price: String(p.price), image: p.image, stockStatus: p.stockStatus, featured: p.featured, category: (p.category as unknown as { _id: string })._id || '' } as typeof EMPTY_FORM)
    setEditId(p._id); setShowForm(true)
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault(); setSaving(true)
    const payload = { ...form, price: Number(form.price), originalPrice: form.originalPrice ? Number(form.originalPrice) : undefined, tags: form.tags ? form.tags.split(',').map((t: string) => t.trim()) : [] }
    const url = editId ? `/api/admin/products/${editId}` : '/api/admin/products'
    const method = editId ? 'PUT' : 'POST'
    const res = await fetch(url, { method, headers, body: JSON.stringify(payload) })
    if (res.ok) { setShowForm(false); fetchAll() }
    setSaving(false)
  }

  async function handleDelete(id: string) {
    if (!confirm('Delete this product?')) return
    await fetch(`/api/admin/products/${id}`, { method: 'DELETE', headers })
    fetchAll()
  }

  const STATUS_BADGE: Record<string, string> = { in_stock: 'badge-green', out_of_stock: 'badge-red', pre_order: 'badge-purple' }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-black text-white">Products</h1>
          <p className="text-gray-500 mt-1">{products.length} products</p>
        </div>
        <button onClick={startCreate} className="btn-primary">+ Add Product</button>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-start justify-center overflow-y-auto p-4">
          <div className="bg-[#13131A] border border-white/10 rounded-2xl w-full max-w-2xl my-8">
            <div className="flex items-center justify-between p-6 border-b border-white/8">
              <h2 className="text-xl font-bold text-white">{editId ? 'Edit' : 'Add'} Product</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-white">✕</button>
            </div>
            <form onSubmit={handleSave} className="p-6 grid grid-cols-2 gap-4">
              {[
                { key: 'name', label: 'Name', type: 'text', required: true, full: true },
                { key: 'price', label: 'Price (₹)', type: 'number', required: true },
                { key: 'originalPrice', label: 'Original Price (₹)', type: 'number' },
                { key: 'image', label: 'Image URL', type: 'url', required: true, full: true },
                { key: 'shortDescription', label: 'Short Description', type: 'text', full: true },
                { key: 'tags', label: 'Tags (comma separated)', type: 'text', full: true },
              ].map(({ key, label, type, required, full }) => (
                <div key={key} className={full ? 'col-span-2' : ''}>
                  <label className="block text-xs font-semibold text-gray-400 mb-1.5">{label}</label>
                  <input type={type} required={required} value={(form as Record<string, unknown>)[key] as string}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    className="input text-sm py-2.5" />
                </div>
              ))}
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">Description *</label>
                <textarea required value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  rows={3} className="input text-sm py-2.5 resize-none" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">Category *</label>
                <select required value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                  className="input text-sm py-2.5">
                  <option value="">Select…</option>
                  {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">Stock Status</label>
                <select value={form.stockStatus} onChange={(e) => setForm((f) => ({ ...f, stockStatus: e.target.value }))}
                  className="input text-sm py-2.5">
                  <option value="in_stock">In Stock</option>
                  <option value="out_of_stock">Out of Stock</option>
                  <option value="pre_order">Pre-Order</option>
                </select>
              </div>
              <div className="col-span-2 flex items-center gap-2">
                <input type="checkbox" id="featured" checked={form.featured} onChange={(e) => setForm((f) => ({ ...f, featured: e.target.checked }))} className="accent-orange-500" />
                <label htmlFor="featured" className="text-sm text-gray-300">Featured product (shown on homepage)</label>
              </div>
              <div className="col-span-2 flex gap-3 pt-2">
                <button type="submit" disabled={saving} className="btn-primary flex-1 disabled:opacity-60">
                  {saving ? 'Saving…' : editId ? 'Update Product' : 'Create Product'}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="btn-ghost px-6">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Products Table */}
      {loading ? (
        <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton h-16 rounded-xl" />)}</div>
      ) : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="border-b border-white/8">
              <tr className="text-xs text-gray-500 uppercase tracking-wider">
                <th className="text-left p-4">Product</th>
                <th className="text-left p-4 hidden md:table-cell">Category</th>
                <th className="text-left p-4">Price</th>
                <th className="text-left p-4 hidden sm:table-cell">Status</th>
                <th className="text-left p-4 hidden lg:table-cell">Featured</th>
                <th className="p-4" />
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {products.map((p) => (
                <tr key={p._id} className="hover:bg-white/2 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="relative w-10 h-10 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                        <Image src={p.image} alt={p.name} fill className="object-cover" sizes="40px" />
                      </div>
                      <span className="font-medium text-white truncate max-w-[180px]">{p.name}</span>
                    </div>
                  </td>
                  <td className="p-4 hidden md:table-cell text-gray-400">{p.category?.name}</td>
                  <td className="p-4 text-orange-400 font-semibold">{formatPrice(p.price)}</td>
                  <td className="p-4 hidden sm:table-cell"><span className={`badge ${STATUS_BADGE[p.stockStatus]}`}>{p.stockStatus.replace('_', ' ')}</span></td>
                  <td className="p-4 hidden lg:table-cell">{p.featured ? <span className="text-yellow-400">⭐ Yes</span> : <span className="text-gray-600">No</span>}</td>
                  <td className="p-4">
                    <div className="flex items-center gap-2 justify-end">
                      <button onClick={() => startEdit(p)} className="text-xs text-gray-400 hover:text-white border border-white/10 hover:border-white/30 px-3 py-1.5 rounded-lg transition-colors">Edit</button>
                      <button onClick={() => handleDelete(p._id)} className="text-xs text-red-400 hover:text-red-300 border border-red-500/20 hover:border-red-500/40 px-3 py-1.5 rounded-lg transition-colors">Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {products.length === 0 && <p className="text-center py-12 text-gray-500">No products yet. Click &quot;Add Product&quot; to get started.</p>}
        </div>
      )}
    </div>
  )
}
