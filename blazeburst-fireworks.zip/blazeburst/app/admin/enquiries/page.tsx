'use client'
import { useState, useEffect } from 'react'
import { formatPrice } from '@/utils/helpers'

type Status = 'all' | 'new' | 'contacted' | 'closed'

interface Enquiry {
  _id: string; name: string; phone: string; city: string; message?: string
  items: Array<{ productName: string; quantity: number; price: number }>
  estimatedTotal: number; status: string; createdAt: string
}

export default function AdminEnquiriesPage() {
  const [enquiries, setEnquiries] = useState<Enquiry[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState<Status>('all')
  const [expanded, setExpanded] = useState<string | null>(null)

  const token = typeof window !== 'undefined' ? localStorage.getItem('bb_admin_token') : ''

  useEffect(() => { fetchEnquiries() }, [statusFilter])

  async function fetchEnquiries() {
    setLoading(true)
    const params = new URLSearchParams({ status: statusFilter, limit: '50' })
    const res = await fetch(`/api/admin/enquiries?${params}`, { headers: { Authorization: `Bearer ${token}` } })
    const data = await res.json()
    setEnquiries(data.enquiries || [])
    setLoading(false)
  }

  async function updateStatus(id: string, status: string) {
    await fetch(`/api/admin/enquiries/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ status }),
    })
    fetchEnquiries()
  }

  async function handleExport() {
    const res = await fetch(`/api/admin/enquiries?export=csv&status=${statusFilter}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `enquiries-${Date.now()}.csv`; a.click()
    URL.revokeObjectURL(url)
  }

  const STATUS_OPTS = ['all', 'new', 'contacted', 'closed'] as Status[]
  const STATUS_CLASS: Record<string, string> = { new: 'badge-orange', contacted: 'badge-green', closed: 'badge-gray' }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-black text-white">Enquiries</h1>
          <p className="text-gray-500 mt-1">{enquiries.length} enquiries</p>
        </div>
        <button onClick={handleExport} className="btn-ghost text-sm py-2 px-4">
          📊 Export CSV
        </button>
      </div>

      {/* Status Filters */}
      <div className="flex gap-2 mb-6">
        {STATUS_OPTS.map((s) => (
          <button key={s} onClick={() => setStatusFilter(s)}
            className={`capitalize px-4 py-2 rounded-lg text-sm font-medium transition-colors ${statusFilter === s ? 'bg-orange-600 text-white' : 'border border-white/10 text-gray-400 hover:text-white'}`}>
            {s}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="skeleton h-20 rounded-xl" />)}</div>
      ) : enquiries.length === 0 ? (
        <div className="text-center py-20 text-gray-500">No enquiries found</div>
      ) : (
        <div className="space-y-3">
          {enquiries.map((e) => (
            <div key={e._id} className="card overflow-hidden">
              <div className="p-5 flex items-center gap-4 cursor-pointer" onClick={() => setExpanded(expanded === e._id ? null : e._id)}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1">
                    <span className="font-bold text-white">{e.name}</span>
                    <span className="text-gray-500 text-xs">{e.city}</span>
                    <span className={`badge ${STATUS_CLASS[e.status]}`}>{e.status}</span>
                  </div>
                  <div className="text-sm text-gray-500 flex items-center gap-4">
                    <span>📞 {e.phone}</span>
                    <span>🛒 {e.items.length} items</span>
                    <span className="text-orange-400 font-semibold">{formatPrice(e.estimatedTotal)}</span>
                    <span>{new Date(e.createdAt).toLocaleDateString('en-IN')}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <select value={e.status} onClick={(ev) => ev.stopPropagation()}
                    onChange={(ev) => updateStatus(e._id, ev.target.value)}
                    className="bg-white/5 border border-white/10 text-sm text-gray-300 rounded-lg px-3 py-1.5 outline-none">
                    <option value="new">New</option>
                    <option value="contacted">Contacted</option>
                    <option value="closed">Closed</option>
                  </select>
                  <a href={`https://wa.me/${e.phone.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" onClick={(ev) => ev.stopPropagation()}
                    className="text-green-400 hover:text-green-300 text-xl transition-colors" title="WhatsApp">💬</a>
                  <span className="text-gray-500">{expanded === e._id ? '▲' : '▼'}</span>
                </div>
              </div>

              {expanded === e._id && (
                <div className="border-t border-white/8 p-5 bg-white/2">
                  <h4 className="text-sm font-bold text-white mb-3">Products Requested</h4>
                  <table className="w-full text-sm">
                    <thead><tr className="text-gray-500 text-xs border-b border-white/8">
                      <th className="text-left pb-2">Product</th>
                      <th className="text-center pb-2">Qty</th>
                      <th className="text-right pb-2">Unit Price</th>
                      <th className="text-right pb-2">Subtotal</th>
                    </tr></thead>
                    <tbody className="divide-y divide-white/5">
                      {e.items.map((item, i) => (
                        <tr key={i} className="py-2">
                          <td className="py-2 text-gray-300">{item.productName}</td>
                          <td className="py-2 text-center text-gray-400">{item.quantity}</td>
                          <td className="py-2 text-right text-gray-400">{formatPrice(item.price)}</td>
                          <td className="py-2 text-right text-orange-400 font-semibold">{formatPrice(item.price * item.quantity)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot><tr className="border-t border-white/15">
                      <td colSpan={3} className="pt-3 text-right font-bold text-white">Total:</td>
                      <td className="pt-3 text-right font-black text-orange-400">{formatPrice(e.estimatedTotal)}</td>
                    </tr></tfoot>
                  </table>
                  {e.message && (
                    <div className="mt-4 bg-white/5 rounded-lg p-3">
                      <span className="text-xs text-gray-500 block mb-1">Customer Note:</span>
                      <p className="text-sm text-gray-300">{e.message}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
