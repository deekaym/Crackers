'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'

interface Category { _id: string; name: string; slug: string; image: string; description?: string; sortOrder: number }

const EMPTY = { name: '', image: '', description: '', sortOrder: '0' }

export default function AdminCategoriesPage() {
  const [cats, setCats] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)

  const token = typeof window !== 'undefined' ? localStorage.getItem('bb_admin_token') : ''
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }

  useEffect(() => { fetch() }, [])

  async function fetch() {
    setLoading(true)
    const res = await window.fetch('/api/admin/categories', { headers })
    const data = await res.json()
    setCats(data.categories || [])
    setLoading(false)
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault(); setSaving(true)
    const payload = { ...form, sortOrder: Number(form.sortOrder) }
    const url = editId ? `/api/admin/categories/${editId}` : '/api/admin/categories'
    const method = editId ? 'PUT' : 'POST'
    const res = await window.fetch(url, { method, headers, body: JSON.stringify(payload) })
    if (res.ok) { setShowForm(false); fetch() }
    setSaving(false)
  }

  async function handleDelete(id: string) {
    if (!confirm('Delete this category?')) return
    await window.fetch(`/api/admin/categories/${id}`, { method: 'DELETE', headers })
    fetch()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-black text-white">Categories</h1>
          <p className="text-gray-500 mt-1">{cats.length} categories</p>
        </div>
        <button onClick={() => { setForm(EMPTY); setEditId(null); setShowForm(true) }} className="btn-primary">+ Add Category</button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#13131A] border border-white/10 rounded-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-6 border-b border-white/8">
              <h2 className="text-xl font-bold text-white">{editId ? 'Edit' : 'Add'} Category</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-white">✕</button>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-4">
              {[
                { key: 'name', label: 'Category Name', type: 'text', required: true },
                { key: 'image', label: 'Image URL', type: 'url', required: true },
                { key: 'description', label: 'Description', type: 'text' },
                { key: 'sortOrder', label: 'Sort Order', type: 'number' },
              ].map(({ key, label, type, required }) => (
                <div key={key}>
                  <label className="block text-xs font-semibold text-gray-400 mb-1.5">{label}</label>
                  <input type={type} required={required} value={(form as Record<string, string>)[key]}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    className="input text-sm py-2.5" />
                </div>
              ))}
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving} className="btn-primary flex-1 disabled:opacity-60">
                  {saving ? 'Saving…' : editId ? 'Update' : 'Create'}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="btn-ghost px-6">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton h-40 rounded-xl" />)}</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {cats.map((c) => (
            <div key={c._id} className="card overflow-hidden">
              <div className="relative aspect-video bg-white/5">
                <Image src={c.image} alt={c.name} fill className="object-cover" sizes="300px" />
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-white text-sm">{c.name}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">/{c.slug}</p>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button onClick={() => { setForm({ name: c.name, image: c.image, description: c.description || '', sortOrder: String(c.sortOrder) }); setEditId(c._id); setShowForm(true) }}
                    className="flex-1 text-xs border border-white/10 hover:border-white/30 text-gray-400 hover:text-white rounded-lg py-1.5 transition-colors">Edit</button>
                  <button onClick={() => handleDelete(c._id)}
                    className="flex-1 text-xs border border-red-500/20 hover:border-red-500/40 text-red-400 hover:text-red-300 rounded-lg py-1.5 transition-colors">Delete</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {!loading && cats.length === 0 && <p className="text-center py-20 text-gray-500">No categories yet.</p>}
    </div>
  )
}
