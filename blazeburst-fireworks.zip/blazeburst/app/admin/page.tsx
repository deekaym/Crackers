import connectDB from '@/lib/db'
import Product from '@/models/Product'
import Enquiry from '@/models/Enquiry'
import Category from '@/models/Category'
import Link from 'next/link'

export const metadata = { title: 'Dashboard' }

async function getStats() {
  await connectDB()
  const [products, categories, enquiries, newEnquiries, revenue] = await Promise.all([
    Product.countDocuments(),
    Category.countDocuments(),
    Enquiry.countDocuments(),
    Enquiry.countDocuments({ status: 'new' }),
    Enquiry.aggregate([{ $group: { _id: null, total: { $sum: '$estimatedTotal' } } }]),
  ])
  const recentEnquiries = await Enquiry.find({}).sort({ createdAt: -1 }).limit(5).lean()
  return {
    products, categories, enquiries, newEnquiries,
    totalEstimated: revenue[0]?.total || 0,
    recentEnquiries: JSON.parse(JSON.stringify(recentEnquiries)),
  }
}

export default async function AdminDashboard() {
  const stats = await getStats()

  const STAT_CARDS = [
    { label: 'Total Enquiries', value: stats.enquiries, icon: '📋', color: 'text-blue-400', href: '/admin/enquiries' },
    { label: 'New Enquiries', value: stats.newEnquiries, icon: '🔔', color: 'text-orange-400', href: '/admin/enquiries?status=new' },
    { label: 'Total Products', value: stats.products, icon: '🎆', color: 'text-purple-400', href: '/admin/products' },
    { label: 'Categories', value: stats.categories, icon: '📁', color: 'text-green-400', href: '/admin/categories' },
  ]

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-black text-white">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back! Here&apos;s what&apos;s happening.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {STAT_CARDS.map(({ label, value, icon, color, href }) => (
          <Link key={label} href={href} className="card p-5 hover:border-white/20 transition-colors">
            <div className="flex items-start justify-between mb-4">
              <span className="text-2xl">{icon}</span>
            </div>
            <div className={`text-3xl font-black ${color} mb-1`}>{value}</div>
            <div className="text-sm text-gray-500">{label}</div>
          </Link>
        ))}
      </div>

      {/* Estimated Revenue */}
      <div className="card p-6 mb-8 border border-orange-500/20 bg-orange-500/5">
        <div className="text-sm text-gray-400 mb-1">Total Estimated Order Value</div>
        <div className="text-4xl font-black gradient-text">₹{stats.totalEstimated.toLocaleString('en-IN')}</div>
        <div className="text-xs text-gray-600 mt-1">Across all enquiries</div>
      </div>

      {/* Recent Enquiries */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold text-white">Recent Enquiries</h2>
          <Link href="/admin/enquiries" className="text-sm text-orange-400 hover:text-orange-300">View all →</Link>
        </div>
        <div className="space-y-3">
          {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
          {stats.recentEnquiries.map((e: any) => (
            <div key={e._id} className="flex items-center justify-between p-3 bg-white/3 rounded-xl">
              <div>
                <div className="text-sm font-semibold text-white">{e.name}</div>
                <div className="text-xs text-gray-500">{e.city} · {e.items.length} items · ₹{e.estimatedTotal.toLocaleString('en-IN')}</div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`badge ${e.status === 'new' ? 'badge-orange' : e.status === 'contacted' ? 'badge-green' : 'badge-gray'}`}>
                  {e.status}
                </span>
                <Link href={`/admin/enquiries`} className="text-xs text-gray-500 hover:text-white">View →</Link>
              </div>
            </div>
          ))}
          {stats.recentEnquiries.length === 0 && (
            <p className="text-gray-500 text-sm text-center py-8">No enquiries yet</p>
          )}
        </div>
      </div>
    </div>
  )
}
