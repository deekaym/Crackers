import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { verifyToken } from '@/lib/auth'
import AdminSidebar from '@/components/admin/AdminSidebar'

export const metadata: Metadata = {
  title: { default: 'Admin Panel', template: '%s | Admin — Blaze & Burst' },
  robots: { index: false, follow: false },
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const token = cookies().get('bb_admin_token')?.value
  const payload = token ? verifyToken(token) : null

  if (!payload) redirect('/admin/login')

  return (
    <div className="min-h-screen bg-[#0A0A0F] flex">
      <AdminSidebar />
      <main className="flex-1 ml-64 p-8 overflow-auto">
        {children}
      </main>
    </div>
  )
}
