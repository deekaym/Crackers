import type { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import connectDB from '@/lib/db'
import Category from '@/models/Category'
import Product from '@/models/Product'
import ProductCard from '@/components/ProductCard'

export const metadata: Metadata = {
  title: 'Blaze & Burst — Premium Fireworks Catalogue | Sivakasi',
  description: 'Browse 500+ premium quality fireworks from Sivakasi. Aerial shots, sparklers, rockets, gift boxes. WhatsApp enquiry. Fast India delivery.',
}

export const revalidate = 300 // 5 min ISR

async function getData() {
  await connectDB()
  const [categories, featuredProducts] = await Promise.all([
    Category.find({}).sort({ sortOrder: 1 }).limit(8).lean(),
    Product.find({ featured: true }).populate('category', 'name slug').limit(8).lean(),
  ])
  return {
    categories: JSON.parse(JSON.stringify(categories)),
    featuredProducts: JSON.parse(JSON.stringify(featuredProducts)),
  }
}

const WHY_US = [
  { icon: '🏭', title: 'Direct from Factory', desc: 'Sourced directly from top Sivakasi manufacturers — no middlemen, best prices guaranteed.' },
  { icon: '✅', title: 'Certified Safe', desc: 'Every product meets government safety standards. Fully licensed and compliant.' },
  { icon: '💬', title: 'WhatsApp Enquiry', desc: 'No complex checkout. Add items and send us a WhatsApp — instant confirmation.' },
  { icon: '🚚', title: 'Pan-India Delivery', desc: 'Reliable delivery across India with proper safety packaging. Free delivery on bulk orders.' },
  { icon: '💰', title: 'Best Prices', desc: 'Wholesale and retail pricing. Volume discounts for bulk & corporate orders.' },
  { icon: '🎁', title: 'Custom Gift Packs', desc: 'Curated assortment boxes for every budget. Perfect for events and corporate gifting.' },
]

const STATS = [
  { num: '500+', label: 'Products' },
  { num: '15K+', label: 'Happy Customers' },
  { num: '50+', label: 'Brands' },
  { num: '12', label: 'Years Experience' },
]

export default async function HomePage() {
  const { categories, featuredProducts } = await getData()
  const waNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER

  return (
    <>
      {/* ───── HERO ───── */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-orange-950/30 via-[#0A0A0F] to-[#0A0A0F]" />
        <div className="absolute top-1/4 right-1/4 w-[600px] h-[600px] bg-orange-600/8 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/3 left-1/3 w-[400px] h-[400px] bg-yellow-500/6 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-20 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center w-full">
          {/* Left */}
          <div>
            <div className="inline-flex items-center gap-2 bg-orange-500/10 border border-orange-500/25 text-orange-300 text-xs font-semibold uppercase tracking-widest px-4 py-2 rounded-full mb-6">
              🎆 Diwali 2025 — New Stock Available
            </div>
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black leading-[0.95] mb-6">
              Light Up
              <br />
              <span className="gradient-text">Every</span>
              <br />
              Celebration
            </h1>
            <p className="text-gray-400 text-lg leading-relaxed max-w-md mb-8">
              Premium fireworks sourced directly from Sivakasi. Browse our catalogue and send your enquiry on WhatsApp — we&apos;ll handle the rest.
            </p>
            <div className="flex flex-wrap gap-3 mb-10">
              <Link href="/products" className="btn-primary text-base px-8 py-4">
                🎇 Browse Catalogue
              </Link>
              <a href={`https://wa.me/${waNumber}?text=${encodeURIComponent('Hi! Please send me your price list.')}`}
                target="_blank" rel="noopener noreferrer"
                className="btn-ghost text-base px-8 py-4">
                📋 Download Price List
              </a>
            </div>
            {/* Stats */}
            <div className="grid grid-cols-4 gap-4">
              {STATS.map(({ num, label }) => (
                <div key={label} className="text-center">
                  <div className="text-2xl font-black gradient-text">{num}</div>
                  <div className="text-xs text-gray-500 mt-0.5">{label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right visual */}
          <div className="hidden lg:flex flex-col gap-4">
            <div className="relative flex items-center justify-center h-64">
              <div className="absolute w-32 h-32 bg-orange-500/20 rounded-full blur-xl animate-pulse" />
              <div className="absolute w-56 h-56 border border-orange-500/15 rounded-full animate-[spin_20s_linear_infinite]" />
              <div className="absolute w-40 h-40 border border-yellow-500/10 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
              <span className="text-8xl animate-float relative z-10">🎆</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="card p-5 text-center">
                <div className="text-3xl font-black gradient-text">500+</div>
                <div className="text-xs text-gray-500 mt-1">Premium Products</div>
              </div>
              <div className="card p-5 text-center">
                <div className="text-3xl font-black gradient-text">15K+</div>
                <div className="text-xs text-gray-500 mt-1">Happy Customers</div>
              </div>
              <div className="card p-5 col-span-2 flex items-center gap-3 border border-green-500/20 bg-green-500/5">
                <span className="text-2xl">✅</span>
                <div>
                  <div className="text-sm font-semibold text-white">Government Certified</div>
                  <div className="text-xs text-gray-500">Licensed & Safety Compliant</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ───── SAFETY BANNER ───── */}
      <div className="bg-amber-500/8 border-y border-amber-500/20 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-3">
          <span className="text-xl flex-shrink-0">⚠️</span>
          <p className="text-sm text-amber-200/80">
            <strong className="text-amber-300">Safety First:</strong> Always use fireworks in open areas, away from flammable materials. Keep children at a safe distance. Read all instructions before use.{' '}
            <Link href="/safety" className="underline text-amber-300 hover:text-amber-200">View Safety Guidelines →</Link>
          </p>
        </div>
      </div>

      {/* ───── CATEGORIES ───── */}
      {categories.length > 0 && (
        <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6">
          <div className="section-label">Browse by Type</div>
          <div className="flex items-end justify-between mb-8">
            <h2 className="text-3xl sm:text-4xl font-black text-white">Shop by Category</h2>
            <Link href="/products" className="text-sm text-orange-400 hover:text-orange-300 font-medium transition-colors">
              View all →
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {categories.map((cat: { _id: string; slug: string; image: string; name: string }) => (
              <Link key={cat._id} href={`/category/${cat.slug}`}
                className="group card p-6 text-center hover:border-orange-500/40 hover:-translate-y-1 transition-all duration-300 hover:shadow-lg hover:shadow-orange-500/10">
                <div className="relative w-16 h-16 mx-auto mb-3 rounded-xl overflow-hidden bg-white/5">
                  <Image src={cat.image} alt={cat.name} fill className="object-cover group-hover:scale-110 transition-transform duration-300" sizes="64px" />
                </div>
                <h3 className="text-sm font-bold text-white group-hover:text-orange-300 transition-colors">{cat.name}</h3>
              </Link>
            ))}
            <Link href="/products"
              className="card p-6 text-center hover:border-orange-500/40 hover:-translate-y-1 transition-all duration-300 flex flex-col items-center justify-center gap-2 border-dashed">
              <span className="text-3xl">+</span>
              <span className="text-sm font-bold text-gray-400">View All</span>
            </Link>
          </div>
        </section>
      )}

      {/* ───── FEATURED PRODUCTS ───── */}
      {featuredProducts.length > 0 && (
        <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6">
          <div className="section-label">Handpicked For You</div>
          <div className="flex items-end justify-between mb-8">
            <h2 className="text-3xl sm:text-4xl font-black text-white">Featured Products</h2>
            <Link href="/products" className="text-sm text-orange-400 hover:text-orange-300 font-medium transition-colors">
              View catalogue →
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
            {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
            {featuredProducts.map((product: any) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        </section>
      )}

      {/* ───── WHY CHOOSE US ───── */}
      <section className="py-16 bg-[#0D0D14]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="section-label">Our Promise</div>
          <div className="flex items-end justify-between mb-10">
            <h2 className="text-3xl sm:text-4xl font-black text-white max-w-md">Why Thousands Choose Blaze & Burst</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {WHY_US.map(({ icon, title, desc }) => (
              <div key={title} className="card p-6 hover:border-orange-500/30 transition-colors">
                <div className="w-12 h-12 bg-orange-500/10 border border-orange-500/20 rounded-xl flex items-center justify-center text-2xl mb-4">
                  {icon}
                </div>
                <h3 className="text-base font-bold text-white mb-2">{title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ───── CTA BANNER ───── */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-orange-950/60 to-yellow-950/40 border border-orange-500/20 p-10 sm:p-16 text-center">
          <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl" />
          <div className="relative">
            <div className="text-5xl mb-4">🎆</div>
            <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">Ready to Light Up Your Celebration?</h2>
            <p className="text-gray-400 max-w-lg mx-auto mb-8">
              Browse our full catalogue, add your favourites, and send us a WhatsApp enquiry. We&apos;ll confirm your order within minutes.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/products" className="btn-primary px-10 py-4 text-base">
                Browse Full Catalogue
              </Link>
              <a href={`https://wa.me/${waNumber}`} target="_blank" rel="noopener noreferrer"
                className="btn-whatsapp px-10 py-4 text-base">
                💬 Enquire on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ───── MOBILE STICKY CTA ───── */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-20 bg-[#0A0A0F]/95 backdrop-blur border-t border-white/10 p-3 flex gap-2">
        <Link href="/products" className="btn-primary flex-1 py-3.5 text-sm justify-center">
          Browse Products
        </Link>
        <a href={`https://wa.me/${waNumber}`} target="_blank" rel="noopener noreferrer"
          className="btn-whatsapp flex-1 py-3.5 text-sm justify-center">
          💬 WhatsApp
        </a>
      </div>
      <div className="h-16 sm:hidden" />
    </>
  )
}
