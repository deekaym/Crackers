import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import connectDB from '@/lib/db'
import Category from '@/models/Category'
import Product from '@/models/Product'
import ProductCard from '@/components/ProductCard'

export const revalidate = 600

interface Props { params: { slug: string } }

async function getData(slug: string) {
  await connectDB()
  const category = await Category.findOne({ slug }).lean()
  if (!category) return null
  const products = await Product.find({ category: category._id }).populate('category', 'name slug').sort({ createdAt: -1 }).lean()
  return {
    category: JSON.parse(JSON.stringify(category)),
    products: JSON.parse(JSON.stringify(products)),
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const data = await getData(params.slug)
  if (!data) return { title: 'Category Not Found' }
  return {
    title: `${data.category.name} Fireworks`,
    description: `Browse premium ${data.category.name} fireworks. Best prices, safe products, fast India delivery.`,
  }
}

export default async function CategoryPage({ params }: Props) {
  const data = await getData(params.slug)
  if (!data) notFound()
  const { category, products } = data

  return (
    <div className="min-h-screen">
      <div className="bg-[#0D0D14] border-b border-white/8 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-xs font-bold text-orange-400 uppercase tracking-widest mb-3">Category</div>
          <h1 className="text-4xl sm:text-5xl font-black text-white mb-3">{category.name}</h1>
          {category.description && <p className="text-gray-500 max-w-xl">{category.description}</p>}
          <p className="text-gray-600 text-sm mt-2">{products.length} products</p>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        {products.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">📦</div>
            <h3 className="text-xl font-bold text-white mb-2">No products yet</h3>
            <p className="text-gray-500">Check back soon or browse other categories.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
            {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
            {products.map((p: any) => <ProductCard key={p._id} product={p} />)}
          </div>
        )}
      </div>
    </div>
  )
}
