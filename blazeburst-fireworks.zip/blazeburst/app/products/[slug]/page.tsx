import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import connectDB from '@/lib/db'
import Product from '@/models/Product'
import ProductCard from '@/components/ProductCard'
import AddToCartButton from '@/components/AddToCartButton'
import { formatPrice } from '@/utils/helpers'

export const revalidate = 600

interface Props { params: { slug: string } }

async function getProduct(slug: string) {
  await connectDB()
  const product = await Product.findOne({ slug }).populate('category', 'name slug').lean()
  if (!product) return null
  return JSON.parse(JSON.stringify(product))
}

async function getRelated(categoryId: string, currentId: string) {
  const related = await Product.find({ category: categoryId, _id: { $ne: currentId } })
    .populate('category', 'name slug').limit(4).lean()
  return JSON.parse(JSON.stringify(related))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const product = await getProduct(params.slug)
  if (!product) return { title: 'Product Not Found' }
  return {
    title: product.name,
    description: product.shortDescription || product.description.slice(0, 160),
    openGraph: { images: [{ url: product.image }] },
  }
}

const STATUS_BADGE: Record<string, string> = {
  in_stock: 'badge badge-green',
  out_of_stock: 'badge badge-red',
  pre_order: 'badge badge-purple',
}
const STATUS_LABEL: Record<string, string> = {
  in_stock: '✅ In Stock',
  out_of_stock: '❌ Out of Stock',
  pre_order: '⏳ Pre-Order',
}

export default async function ProductPage({ params }: Props) {
  const product = await getProduct(params.slug)
  if (!product) notFound()

  const related = await getRelated(product.category._id, product._id)

  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
    description: product.description,
    image: product.image,
    offers: {
      '@type': 'Offer',
      price: product.price,
      priceCurrency: 'INR',
      availability: product.stockStatus === 'in_stock'
        ? 'https://schema.org/InStock'
        : 'https://schema.org/OutOfStock',
    },
  }

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />

      <div className="min-h-screen">
        {/* Breadcrumb */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5">
          <nav className="flex items-center gap-2 text-sm text-gray-500">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link href="/products" className="hover:text-white transition-colors">Products</Link>
            <span>/</span>
            <Link href={`/category/${product.category.slug}`} className="hover:text-white transition-colors">
              {product.category.name}
            </Link>
            <span>/</span>
            <span className="text-gray-300 truncate max-w-[200px]">{product.name}</span>
          </nav>
        </div>

        {/* Main product section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Images */}
            <div className="space-y-3">
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-[#1C1C26] border border-white/8">
                <Image src={product.image} alt={product.name} fill className="object-cover" sizes="(max-width: 1024px) 100vw, 50vw" priority />
              </div>
              {product.images?.length > 0 && (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {[product.image, ...product.images].slice(0, 5).map((img: string, i: number) => (
                    <div key={i} className="relative w-20 h-20 flex-shrink-0 rounded-xl overflow-hidden bg-[#1C1C26] border border-white/8">
                      <Image src={img} alt={`${product.name} ${i + 1}`} fill className="object-cover" sizes="80px" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Info */}
            <div className="lg:sticky lg:top-20">
              <div className="text-xs font-bold text-orange-400 uppercase tracking-widest mb-2">
                {product.category.name}
              </div>
              <h1 className="text-3xl sm:text-4xl font-black text-white leading-tight mb-4">{product.name}</h1>

              <div className="flex items-center gap-3 mb-6">
                <span className={STATUS_BADGE[product.stockStatus]}>{STATUS_LABEL[product.stockStatus]}</span>
              </div>

              <div className="flex items-end gap-3 mb-6">
                <div className="text-4xl font-black gradient-text">{formatPrice(product.price)}</div>
                {product.originalPrice && (
                  <div className="text-lg text-gray-500 line-through mb-1">{formatPrice(product.originalPrice)}</div>
                )}
              </div>

              <p className="text-gray-400 leading-relaxed mb-6">{product.description}</p>

              {product.tags?.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-6">
                  {product.tags.map((tag: string) => (
                    <span key={tag} className="text-xs bg-white/5 border border-white/10 text-gray-400 px-3 py-1 rounded-lg">{tag}</span>
                  ))}
                </div>
              )}

              {product.specifications && Object.keys(product.specifications).length > 0 && (
                <div className="card p-4 mb-6">
                  <h3 className="text-sm font-bold text-white mb-3">Specifications</h3>
                  <dl className="space-y-2">
                    {Object.entries(product.specifications).map(([k, v]) => (
                      <div key={k} className="flex gap-3 text-sm">
                        <dt className="text-gray-500 w-32 flex-shrink-0">{k}</dt>
                        <dd className="text-gray-300">{v as string}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              )}

              <div className="space-y-3">
                <AddToCartButton product={{ _id: product._id, name: product.name, price: product.price, image: product.image, slug: product.slug, stockStatus: product.stockStatus }} />
                <a href={`https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hi! I'm interested in ${product.name} (₹${product.price}). Please share availability and delivery details.`)}`}
                  target="_blank" rel="noopener noreferrer"
                  className="btn-whatsapp w-full py-4">
                  💬 Enquire Directly on WhatsApp
                </a>
              </div>

              <div className="mt-6 flex items-center gap-6 text-sm text-gray-500">
                <span className="flex items-center gap-1.5">🚚 Pan-India delivery</span>
                <span className="flex items-center gap-1.5">✅ Licensed product</span>
              </div>
            </div>
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
            <h2 className="text-2xl font-black text-white mb-6">Related Products</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
              {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
              {related.map((p: any) => <ProductCard key={p._id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </>
  )
}
