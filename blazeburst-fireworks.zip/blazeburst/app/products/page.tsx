'use client'
import { useState, useEffect, useCallback, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import ProductCard from '@/components/ProductCard'

interface Product {
  _id: string; name: string; slug: string; price: number; originalPrice?: number
  image: string; shortDescription?: string; description: string
  stockStatus: string; category: { name: string; slug: string }; tags?: string[]
}
interface Category { _id: string; name: string; slug: string }

function ProductsContent() {
  const searchParams = useSearchParams()
  const router = useRouter()

  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)

  const [search, setSearch] = useState(searchParams.get('search') || '')
  const [category, setCategory] = useState(searchParams.get('category') || '')
  const [minPrice, setMinPrice] = useState(searchParams.get('minPrice') || '')
  const [maxPrice, setMaxPrice] = useState(searchParams.get('maxPrice') || '')
  const [stockStatus, setStockStatus] = useState(searchParams.get('stockStatus') || '')

  const LIMIT = 12

  useEffect(() => {
    fetch('/api/categories').then((r) => r.json()).then((d) => setCategories(d.categories || []))
  }, [])

  const fetchProducts = useCallback(async (pg = 1) => {
    setLoading(true)
    const params = new URLSearchParams({ page: String(pg), limit: String(LIMIT) })
    if (search) params.set('search', search)
    if (category) params.set('category', category)
    if (minPrice) params.set('minPrice', minPrice)
    if (maxPrice) params.set('maxPrice', maxPrice)
    if (stockStatus) params.set('stockStatus', stockStatus)

    try {
      const res = await fetch(`/api/products?${params}`)
      const data = await res.json()
      setProducts(data.products || [])
      setTotal(data.pagination?.total || 0)
      setPage(pg)
    } finally {
      setLoading(false)
    }
  }, [search, category, minPrice, maxPrice, stockStatus])

  useEffect(() => { fetchProducts(1) }, [fetchProducts])

  function clearFilters() {
    setSearch(''); setCategory(''); setMinPrice(''); setMaxPrice(''); setStockStatus('')
  }

  const hasFilters = search || category || minPrice || maxPrice || stockStatus
  const pages = Math.ceil(total / LIMIT)

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-[#0D0D14] border-b border-white/8 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-xs font-bold text-orange-400 uppercase tracking-widest mb-3">Our Products</div>
          <h1 className="text-4xl sm:text-5xl font-black text-white mb-3">Fireworks Catalogue</h1>
          <p className="text-gray-500 max-w-xl">Browse our full range of premium fireworks. Add products to your enquiry cart and send us a WhatsApp message.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="flex gap-8">
          {/* ── Sidebar Filters ── */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="card p-5 sticky top-20 space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white mb-3">Search</h3>
                <input type="search" placeholder="Search products…" value={search}
                  onChange={(e) => setSearch(e.target.value)} className="input" />
              </div>

              <div>
                <h3 className="text-sm font-bold text-white mb-3">Category</h3>
                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="cat" checked={!category} onChange={() => setCategory('')} className="accent-orange-500" />
                    <span className="text-sm text-gray-400">All Categories</span>
                  </label>
                  {categories.map((c) => (
                    <label key={c._id} className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="cat" checked={category === c._id} onChange={() => setCategory(c._id)} className="accent-orange-500" />
                      <span className="text-sm text-gray-400">{c.name}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-bold text-white mb-3">Price Range</h3>
                <div className="flex gap-2">
                  <input type="number" placeholder="Min ₹" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} className="input text-xs py-2" />
                  <input type="number" placeholder="Max ₹" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} className="input text-xs py-2" />
                </div>
              </div>

              <div>
                <h3 className="text-sm font-bold text-white mb-3">Availability</h3>
                <select value={stockStatus} onChange={(e) => setStockStatus(e.target.value)}
                  className="input text-sm py-2">
                  <option value="">All</option>
                  <option value="in_stock">In Stock</option>
                  <option value="pre_order">Pre-Order</option>
                </select>
              </div>

              {hasFilters && (
                <button onClick={clearFilters} className="w-full text-sm text-gray-400 hover:text-white border border-white/10 hover:border-white/30 rounded-lg py-2 transition-colors">
                  Clear Filters
                </button>
              )}
            </div>
          </aside>

          {/* ── Products Grid ── */}
          <div className="flex-1 min-w-0">
            {/* Mobile filters */}
            <div className="lg:hidden mb-5 flex gap-2 overflow-x-auto pb-2">
              <input type="search" placeholder="🔍 Search…" value={search}
                onChange={(e) => setSearch(e.target.value)} className="input text-sm py-2 min-w-0 flex-1" />
              <select value={category} onChange={(e) => setCategory(e.target.value)}
                className="input text-sm py-2 flex-shrink-0">
                <option value="">All Categories</option>
                {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
              </select>
            </div>

            {/* Count */}
            <div className="flex items-center justify-between mb-6">
              <p className="text-sm text-gray-500">
                {loading ? 'Loading…' : `${total} product${total !== 1 ? 's' : ''} found`}
              </p>
              {hasFilters && (
                <button onClick={clearFilters} className="text-xs text-orange-400 hover:text-orange-300">
                  Clear all filters
                </button>
              )}
            </div>

            {/* Grid */}
            {loading ? (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-5">
                {Array.from({ length: 9 }).map((_, i) => (
                  <div key={i} className="rounded-2xl overflow-hidden">
                    <div className="skeleton aspect-[4/3]" />
                    <div className="p-4 space-y-2">
                      <div className="skeleton h-3 w-1/3 rounded" />
                      <div className="skeleton h-4 w-3/4 rounded" />
                      <div className="skeleton h-3 w-full rounded" />
                      <div className="skeleton h-3 w-2/3 rounded" />
                    </div>
                  </div>
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-xl font-bold text-white mb-2">No products found</h3>
                <p className="text-gray-500 mb-6">Try adjusting your filters or search terms</p>
                <button onClick={clearFilters} className="btn-primary">Clear Filters</button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-5">
                {products.map((p) => <ProductCard key={p._id} product={p} />)}
              </div>
            )}

            {/* Pagination */}
            {pages > 1 && (
              <div className="flex justify-center gap-2 mt-10">
                <button disabled={page <= 1} onClick={() => fetchProducts(page - 1)}
                  className="px-4 py-2 rounded-lg border border-white/10 text-sm text-gray-400 hover:text-white hover:border-white/30 disabled:opacity-30 transition-colors">
                  ← Prev
                </button>
                {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
                  <button key={p} onClick={() => fetchProducts(p)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${p === page ? 'bg-orange-600 text-white' : 'border border-white/10 text-gray-400 hover:text-white'}`}>
                    {p}
                  </button>
                ))}
                <button disabled={page >= pages} onClick={() => fetchProducts(page + 1)}
                  className="px-4 py-2 rounded-lg border border-white/10 text-sm text-gray-400 hover:text-white hover:border-white/30 disabled:opacity-30 transition-colors">
                  Next →
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function ProductsPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><div className="text-gray-500">Loading…</div></div>}>
      <ProductsContent />
    </Suspense>
  )
}
