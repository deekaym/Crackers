import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Firecracker Safety Guidelines',
  description: 'Essential safety guidelines for using fireworks. Legal compliance, age restrictions, government disclaimers. Always use fireworks responsibly.',
}

const GUIDELINES = [
  { icon: '👀', title: 'Read Before Use', desc: 'Always read all instructions and warnings printed on the package before using any fireworks.' },
  { icon: '🌳', title: 'Open Areas Only', desc: 'Only use fireworks outdoors in large, open spaces away from buildings, trees, dry grass, and flammable materials.' },
  { icon: '🧑‍🤝‍🧑', title: 'Adult Supervision', desc: 'All fireworks must be supervised by a responsible adult. Never leave children alone with fireworks.' },
  { icon: '💧', title: 'Keep Water Ready', desc: 'Always have a bucket of water or garden hose nearby in case of fire or for soaking used fireworks.' },
  { icon: '🚫', title: 'No Re-lighting', desc: 'Never attempt to re-light a dud firework. Wait 30 minutes, then soak it in water before disposal.' },
  { icon: '👓', title: 'Wear Protection', desc: 'Use appropriate eye and ear protection. Never hold lit fireworks in your hand.' },
  { icon: '📦', title: 'Safe Storage', desc: 'Store fireworks in a cool, dry place away from heat sources. Keep in original packaging until use.' },
  { icon: '🚗', title: 'Safe Distance', desc: 'Maintain safe distances: 25m for small items, 75m for aerial shells. Stand to the side, never over.' },
  { icon: '🐾', title: 'Protect Animals', desc: 'Keep pets and animals indoors. Loud sounds cause extreme distress and animals may flee.' },
  { icon: '📵', title: 'No Modifications', desc: 'Never modify fireworks or attempt to make homemade explosives. This is illegal and extremely dangerous.' },
  { icon: '🍺', title: 'No Alcohol', desc: 'Never use fireworks under the influence of alcohol or drugs. This is illegal and life-threatening.' },
  { icon: '♻️', title: 'Proper Disposal', desc: 'After use, soak spent fireworks in water for several hours before disposing in waste bin.' },
]

const LEGAL_ITEMS = [
  'All fireworks sold by Blaze & Burst are licensed by the Government of India under the Explosives Act, 1884.',
  'Sale of fireworks to persons under 18 years of age is strictly prohibited.',
  'Use of fireworks is subject to local state regulations. Check your local laws before purchasing.',
  'Community fireworks shows may require additional permits from local authorities.',
  'High-decibel crackers (above 125 dB) are banned in many states per Supreme Court directives.',
  'Fireworks must not be used in silence zones: 100m radius of hospitals, educational institutions, courts, and religious places.',
  'Night-time restrictions apply in many cities. Typically allowed 8 PM–10 PM on permitted festival days.',
  'Green crackers meeting CSIR-NEERI standards are the only crackers permitted in some states.',
]

export default function SafetyPage() {
  const waNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-b from-amber-950/30 to-[#0A0A0F] border-b border-amber-500/15 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <div className="text-5xl mb-4">⚠️</div>
          <h1 className="text-4xl sm:text-5xl font-black text-white mb-4">Safety Guidelines</h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Fireworks are beautiful but must be handled with care. Please read all safety guidelines before use. Safety is our highest priority.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-12">
        {/* Age restriction banner */}
        <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-6 flex items-start gap-4">
          <span className="text-4xl flex-shrink-0">🔞</span>
          <div>
            <h2 className="text-xl font-black text-white mb-2">Age Restriction: 18+ Only</h2>
            <p className="text-gray-400 leading-relaxed">
              Sale and use of fireworks is strictly restricted to persons <strong className="text-white">18 years of age and older</strong>. By purchasing from us, you confirm you are legally an adult in your jurisdiction. It is illegal to supply fireworks to minors.
            </p>
          </div>
        </div>

        {/* Safety guidelines grid */}
        <section>
          <h2 className="text-2xl font-black text-white mb-6">Essential Safety Rules</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {GUIDELINES.map(({ icon, title, desc }) => (
              <div key={title} className="card p-5 flex gap-4">
                <span className="text-2xl flex-shrink-0 mt-0.5">{icon}</span>
                <div>
                  <h3 className="font-bold text-white text-sm mb-1">{title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Legal compliance */}
        <section>
          <h2 className="text-2xl font-black text-white mb-6">Legal Compliance & Disclaimers</h2>
          <div className="card p-6 space-y-3">
            {LEGAL_ITEMS.map((item, i) => (
              <div key={i} className="flex items-start gap-3">
                <span className="text-orange-400 mt-0.5 flex-shrink-0">▸</span>
                <p className="text-gray-400 text-sm leading-relaxed">{item}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Disclaimer */}
        <section className="bg-amber-500/8 border border-amber-500/20 rounded-2xl p-6">
          <h2 className="text-lg font-black text-amber-300 mb-3">⚠️ Disclaimer</h2>
          <div className="space-y-2 text-sm text-amber-200/70 leading-relaxed">
            <p>Blaze & Burst sells fireworks solely for lawful use by responsible adults. We are not liable for any injury, damage, or loss resulting from misuse, improper handling, or violation of local laws.</p>
            <p>Customers are solely responsible for ensuring fireworks are used in accordance with all applicable local, state, and national laws and regulations.</p>
            <p>By purchasing our products, you acknowledge that you have read and agree to abide by all safety guidelines and legal requirements.</p>
          </div>
        </section>

        {/* Emergency contacts */}
        <section className="card p-6">
          <h2 className="text-xl font-black text-white mb-4">Emergency Contacts</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            {[
              { num: '101', label: 'Fire Department', icon: '🔥' },
              { num: '108', label: 'Medical Emergency', icon: '🏥' },
              { num: '100', label: 'Police', icon: '🚔' },
            ].map(({ num, label, icon }) => (
              <div key={num} className="bg-white/5 rounded-xl p-4">
                <div className="text-3xl mb-1">{icon}</div>
                <div className="text-2xl font-black text-white">{num}</div>
                <div className="text-xs text-gray-500 mt-1">{label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <div className="text-center">
          <p className="text-gray-500 mb-4 text-sm">Have safety questions? Contact us before purchasing.</p>
          <div className="flex flex-wrap gap-3 justify-center">
            <a href={`https://wa.me/${waNumber}?text=${encodeURIComponent('Hi! I have a safety question about your fireworks.')}`}
              target="_blank" rel="noopener noreferrer" className="btn-whatsapp">
              💬 Ask Safety Questions
            </a>
            <Link href="/products" className="btn-ghost">Browse Catalogue</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
