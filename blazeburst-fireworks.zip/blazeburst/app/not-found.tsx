import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
      <div className="text-7xl mb-6">🎆</div>
      <h1 className="text-5xl font-black text-white mb-3">404</h1>
      <h2 className="text-xl font-bold text-gray-300 mb-3">Page Not Found</h2>
      <p className="text-gray-500 max-w-md mb-8">
        Looks like this page went up in smoke! Let&apos;s get you back to the good stuff.
      </p>
      <div className="flex gap-3">
        <Link href="/" className="btn-primary">← Back to Home</Link>
        <Link href="/products" className="btn-ghost">Browse Products</Link>
      </div>
    </div>
  )
}
